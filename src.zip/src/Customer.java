
public class Customer extends Person{
	
	int seatID;
	
	public Customer(String name) {
		super(name);
		//this.seatID = seatID;
	}

}
