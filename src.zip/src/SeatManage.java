
public class SeatManage {

	boolean setTable[][];
	
	
	public SeatManage() {
		
		setTable = new boolean[][]{{false, false, false, false, false},
			{false, false, false, false, false}};
			
	}
	
	public void clear() {
		
		
		setTable = new boolean[][]{{false, false, false, false, false},
			{false, false, false, false, false}};
	}
	
	public void print() {
		System.out.println();
		
		for (int i=0; i<2; i++) {
			for (int j=0; j<5; j++) {
				
				if (setTable[i][j] == false)
					System.out.print("V"+ "["+(i+1)+"]"+"["+(j+1)+"]" + "  ");
				else
					System.out.print("C"+ "["+(i+1)+"]"+"["+(j+1)+"]" + "  ");
				
			}
			System.out.println();
		}
		
		System.out.println();
	}
	
	public void setSeat(int x, int y) {
		
		if (setTable[x-1][y] == false) {
			setTable[x-1][y] = true;
			System.out.println("���õǾ����ϴ�.");
			System.out.println();
		}
		else
			System.out.println("�̹� ��� ���Դϴ�.");
	}
	
	public void releaseSeat(int x, int y) {
		if (setTable[x-1][y] == true)
			setTable[x-1][y] = false;
		
	}

}
