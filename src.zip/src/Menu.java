
import java.util.Scanner;

public class Menu {

	public static void main(String[] args) {
		
		while(true) {
			System.out.println("[LaLa StudyRoom]");
			System.out.println("1. ����");
			System.out.println("2. ����");
			System.out.println("3. ������");
			System.out.println("4. ����");
			System.out.print("--->");
			
			Scanner scan = new Scanner(System.in);
			int input = scan.nextInt();
			
			Management management = new Management();
			
			if (input == 1) {
				management.setIn();
			}
			else if (input == 2) {
				management.setOut();
			}
			else if (input == 3) {
				management.admin();
			}
			else if (input == 4) {
				System.out.print("���α׷��� ����˴ϴ�.");
				break;
			}
		}
			
	}

}
